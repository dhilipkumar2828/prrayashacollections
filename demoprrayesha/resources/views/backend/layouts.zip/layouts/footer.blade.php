<footer class="footer">
    © 2018 - 2020<b> E-commerce<b>
</footer>
