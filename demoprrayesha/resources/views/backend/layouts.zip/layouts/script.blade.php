<script src="{{asset('assets/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('assets/js/modernizr.min.js')}}"></script>
<script src="{{asset('assets/js/detect.js')}}"></script>
<script src="{{asset('assets/js/fastclick.js')}}"></script>
<script src="{{asset('assets/js/jquery.slimscroll.js')}}"></script>
<script src="{{asset('assets/js/jquery.blockUI.js')}}"></script>
<script src="{{asset('assets/js/waves.js')}}"></script>
<script src="{{asset('assets/js/jquery.nicescroll.js')}}"></script>
<script src="{{asset('assets/js/jquery.scrollTo.min.js')}}"></script>

<!-- skycons -->
<script src="{{asset('assets/plugins/skycons/skycons.min.js')}}"></script>

<!-- skycons -->
<script src="{{asset('assets/plugins/peity/jquery.peity.min.js')}}"></script>

<script src="{{asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>

<script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>


 <!-- Required datatable js -->
 <script src="{{asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
 <!-- Buttons examples -->
 <script src="{{asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/jszip.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/pdfmake.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/vfs_fonts.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/buttons.html5.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/buttons.print.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
 <!-- Responsive examples -->
 <script src="{{asset('assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
 <script src="{{asset('assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

 <!-- Datatable init js -->
 <script src="{{asset('assets/pages/datatables.init.js')}}"></script>

 <script src="{{asset('assets/plugins/RWD-Table-Patterns/dist/js/rwd-table.min.js')}}"></script>

<!-- App js -->
<script src="{{asset('assets/js/app.js')}}"></script>



<!--Morris Chart-->
<script src="{{asset('assets/plugins/morris/morris.min.js')}}"></script>
<script src="{{asset('assets/plugins/raphael/raphael-min.js')}}"></script>

<!-- dashboard -->
<script src="{{asset('assets/pages/dashboard.js')}}"></script>



<script src="{{asset('assets/plugins/tinymce/tinymce.min.js')}}"></script>



<script src="{{asset('assets/switch-button-bootstrap/src/bootstrap-switch-button.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

@yield('scripts')





<script>
    setTimeout(function () {
        $('#alert').slideUp();
    },4000);

    $(document).ready(function() {
                $('form').parsley();
            });
            $(function() {
                $('.table-responsive').responsiveTable({
                    addDisplayAllBtn: true,
                    addFocusBtn:false
                });
            });
            $('.has_sub ul li a').click(function(){
  $(this).parent().toggleClass('active')
})
</script>
