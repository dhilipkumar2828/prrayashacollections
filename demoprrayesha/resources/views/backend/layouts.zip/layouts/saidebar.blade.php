
 <div class="left side-menu">
    <button type="button" class="button-menu-mobile button-menu-mobile-topbar open-left waves-effect">
        <i class="ion-close"></i>
    </button>

    <div class="left-side-logo d-block d-lg-none">
        <div class="text-center">

            <a href="{{route('admin')}}" class="logo"><img src="assets/images/logo-dark.png" height="20" alt="logo"></a>
        </div>
    </div>

<div class="sidebar-inner slimscrollleft">

    <div id="sidebar-menu">
        <ul>
            <li class="menu-title">Main</li>
            @hasrole('admin')

            <li>
                <a href="{{route('admin')}}" class="waves-effect">
                    <i class="dripicons-meter"></i>
                    <span> Dashboard <span class="badge badge-success badge-pill float-right"></span></span>
                </a>
            </li>

            @else
            @endhasrole
          

            @if(auth()->user()->can('Banner List') or auth()->user()->can('Promo List') or auth()->user()->can('Deals List') )
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-cubes"></i><span>  Appearence</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                @hasrole('admin')
                <li>
    <a href="{{route('deals.store')}}" class="waves-effect"><span> Deals Of the Day </span></a>
</li>
@endhasrole
                @can('Banner List')

<li>
    <a href="{{route('banner.index')}}" class="waves-effect" ><span> Banner </span></a>
</li>
@endcan

@can('Promo List')
<li>
    <a href="{{route('promo.index')}}" class="waves-effect"><span> Promo </span></a>
</li>
@endcan

            </ul>
</li>   

            @endif
           
           

            @if(auth()->user()->can('Category Group List') or auth()->user()->can('Category Sub Group List') or auth()->user()->can('Category List') or auth()->user()->can('Product List') or auth()->user()->can('Brand List') or auth()->user()->can('Attribute List') or auth()->user()->can('Tax List') or auth()->user()->can('Product Riviewes'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-product-hunt"></i><span>  Catelogs</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                
       
                    <li>
                        @can('Category List')
                        <a href="{{route('category.index')}}">Categories</a>
                        @endcan

                    </li>
                    <li>
                        @can('Brand List')
                        <a href="{{route('brand.index')}}">Manufacturers</a>
                        @endcan
                    </li>
                    <li>
                        @can('Attribute List')
                        <a href="{{route('attribute.index')}}">Attributes</a>
                        @endcan
                    </li>
                    <li>
                        @can('Tax List')
                        <a href="{{route('tax.index')}}">Tax</a>
                        @endcan
                    </li>
                    <li>
                        @can('Product List')
                        <a href="{{route('product.index')}}">Products</a>
                        @endcan
                    </li>                 
                    <li>
                        @can('Product Riviewes')
                        <a href="{{route('product.riviewes')}}">Product Reviews</a>
                        @endcan
                    </li>
                </ul>
            </li>
            @else
            @endif

              
            @if(auth()->user()->can('Vendor List'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-users"></i><span>Vendors</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">

                <li>
                        @can('Vendor List')
                        <a href="{{ route('vendors.index') }}">Vendor</a>

                        @endcan
                    </li>
</ul>
</li>    
@else
            @endif


            @if(auth()->user()->can('Warehouse List') or auth()->user()->can('Supplier List'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa fa-object-ungroup"></i><span>Stock</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                <!--<li>-->
                 
                <!--        <a href="{{ route('product.listproduct') }}">Inventory</a>-->
                       
                <!--    </li>-->
                <li>
                        @can('Warehouse List')
                        <a href="{{ route('warehouse.index') }}">Warehouse</a>
                        @endcan
                    </li>
                <li>
                        @can('Supplier List')
                        <a href="{{ route('suppliers.index') }}">Suppliers</a>

                        @endcan
                    </li>
</ul>
</li>    
@else
            @endif


            @if(auth()->user()->can('Vendor Item List') or auth()->user()->can('Purchase List') or auth()->user()->can('Quotation List')or auth()->user()->can('Purchase Order List')or auth()->user()->can('Invoice List'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-shopping-cart"></i><span>Purchase</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                  
                    <li>
                        @can('Vendor Item List')
                        <a href="{{ route('vendoritem.index') }}">Vendor Items</a>
                        @endcan
                    </li>
                    <li>
                        @can('Purchase List')
                        <a href="{{ route('purchase.index') }}">Purchase Request</a>
                        @endcan
                    </li>
                    <li>
                        @can('Quotation List')
                        <a href="{{ route('quotation.index') }}">Quotations</a>
                        @endcan
                    </li>
                    <li>
                        @can('Purchase Order List')
                        <a href="{{ route('purchaseorder.index') }}">Purchase Order</a>
                        @endcan
                    </li>
                    <li>
                        @can('Invoice List')
                        <a href="{{ route('invoice.index') }}">Invoices</a>
                        @endcan
                    </li>
                </ul>
            </li>
            @else
            @endif
            @if(auth()->user()->can('Inventory List') or auth()->user()->can('Inventory History List') or auth()->user()->can('Inventory Loss Adjustment List') or auth()->user()->can('Warehouse List'))
            <li class="has_sub">
            
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-yelp"></i><span>Inventory</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                
                <ul class="list-unstyled">
                    <li>
                 
                        <a href="{{ route('product.listproduct') }}">List Products</a>
                       
                    </li>
                    
                    <li>
                        @can('Inventory List')
                        <a href="{{ route('inventory.index') }}">Inventory Receiving Vocher</a>
                        @endcan
                    </li>
                   
                    <li>
                        @can('Inventory Loss Adjustment List')
                        <a href="{{ route('inventory.loss-adjust') }}">Loss & Adjustment</a>
                        @endcan
                       
                    </li>
                   
                    <li>
                        @can('Inventory History List')
                        <a href="{{ route('inventory.inventoryhistory') }}">Inventory Histroy</a>
                        @endcan
                    </li>
                </ul>
            </li>
            @else
            @endif
            @if(auth()->user()->can('Order List') or auth()->user()->can('Pending List') or auth()->user()->can('Confirmed List') or auth()->user()->can('Progress List') or auth()->user()->can('Deliver List') or auth()->user()->can('Return List') or auth()->user()->can('Cancel List') or auth()->user()->can('COD List'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-first-order"></i><span>  Orders</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                    <li>
                        @can('Order List')
                        <a href="{{ route('order.index') }}">All Orders</a>
                        @endcan
                    </li>
                    <li>
                        @can('Pending List')
                        <a href="{{ route('pending') }}">Pending Orders</a>
                        @endcan
                    </li>
                    <li>
                        @can('Confirmed List')
                        <a href="{{ route('confirmed') }}">Confirmed Orders</a>
                        @endcan
                    </li>
                    <li>
                       @can('Progress List')
                        <a href="{{ route('progress') }}">Processing Orders</a>
                        @endcan
                    </li>
                    <li>
                       @can('Deliver List')
                        <a href="{{ route('deliver') }}">Delivered Orders</a>
                        @endcan
                    </li>
                    <li>
                        @can('Return List')
                        <a href="{{ route('return') }}">Returned Orders</a>
                        @endcan
                    </li>
                    <li>
                        @can('Cancel List')
                        <a href="{{ route('cancel') }}">Cancelled Orders</a>
                        @endcan
                    </li>
                    <li>
                        @can('COD List')
                        <a href="{{ route('cod') }}">COD Orders</a>
                        @endcan
                    </li>
                </ul>
            </li>

            @else
            @endif
            @if(auth()->user()->can('Transactions List'))
            <li>
            @can('Transactions List')
            <a href="{{route('transactions')}}" class="waves-effect"><i class="fa fa-random"></i><span> Transactions </span></a>
            @endcan
            </li>
            @else
            @endif
            @if(auth()->user()->can('Payments List') or auth()->user()->can('Pending Payments List') or auth()->user()->can('Approved Payments List') or auth()->user()->can('Payment Method Create'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-newspaper-o"></i><span> Payments </span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">

                    <li>
                    @can('Payment Method Create')
                    <a href="{{route('payment-method')}}">Payment Method</a>
                    @endcan
                    </li>
                    <li>
                        @can('Payments List')
                        <a href="{{route('allPayments')}}">All Payments</a>
                        @endcan
                    </li>
                    <li>
                        @can('Pending Payments List')
                        <a href="{{route('payment_pending')}}">Pending Payments</a>
                        @endcan
                    </li>
                    <li>
                        @can('Approved Payments List')
                        <a href="{{route('Approved_Payments')}}">Approved Payments</a>
                        @endcan
                    </li>
                </ul>
            </li>
            @else
            @endif

            @if(auth()->user()->can(''))
            @else

            @endif
            @if(auth()->user()->can('Coupon List') or auth()->user()->can('Coupon create'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-gift"></i><span>  Coupon</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">

                    <li>
                        @can('Coupon create')
                        <a href="{{route('coupon.create')}}">Add Coupon</a>
                        @endcan
                    </li>
                    <li>
                        @can('Coupon List')
                        <a href="{{route('coupon.index')}}">View Coupon</a>
                        @endcan
                    </li>

                </ul>
            </li>
            @else
            @endif

            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-list-alt"></i><span> Suborders Category</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">

                    <li>
                        @can('Coupon create')
                        <a href="{{route('suborders.suborders')}}">Suborders</a>
                        @endcan
                    </li>
                

                </ul>
            </li>
            @hasrole('admin')
            <li>
                <a href="shipping.html" class="waves-effect"><i class="fa fa-ship"></i><span> Shipping

                </span></a>
            </li>
            <li>
                <a href="{{url('subscribers')}}" class="waves-effect"><i class="fa fa-bell"></i><span> Subscribers

                </span></a>
            </li>
            @else
            @endhasrole
           

            @if(auth()->user()->can('Visitors List') or auth()->user()->can('Sales Report List') or auth()->user()->can('Product Sales Report List') or auth()->user()->can('Product Purchase Report List') or auth()->user()->can('Product Stock Report List') or auth()->user()->can('Expense Report List'))
            <li class="has_sub">
                
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-file"></i><span> Reports </span> <span
                        class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                     <li>
                        @can('Visitors List')
                        <a href="{{route('visitors')}}">Visitors</a>
                        @endcan
                    </li>
                    <li>
                        @can('Sales Report List')
                        <a href="{{ route('report.index') }}">Sales Report</a>
                        @endcan
                    </li>
                    <li>
                       @can('Product Sales Report List')
                        <a href="{{ route('report.productsalesreport') }}">Product Sales Report</a>
                        @endcan
                    </li>
                    <li>
                        @can('Product Purchase Report List')
                        <a href="{{ route('report.productpurchasereport') }}">Product Purchase Report</a>
                        @endcan
                    </li>
                    <li>
                        @can('Product Stock Report List')
                        <a href="{{ route('report.productstockreport') }}">Product Stock Report</a>
                        @endcan
                    </li>
                    <!-- <li><a href="{{ route('report.taxreport') }}">Tax Report</a></li> -->
                    <li>
                       @can('Expense Report List')
                        <a href="{{ route('report.expensereport') }}">Expense Report</a>
                        @endcan
                    </li>
                </ul>
            </li>
            @else
            @endif

        

            @if(auth()->user()->can(''))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-comment"></i><span> Support Tickets</span> <span
                        class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
                    <li><a href="all-tickets.html">All Tickets  </a></li>
                    <li><a href="pending-tickets.html">Pending Tickets</a></li>
                    <li><a href="closed-tickets.html">Closed Tickets</a></li>
                </ul>
            </li>
            @else
            @endif
           
            @if(auth()->user()->can('User List') or auth()->user()->can('Customer List'))
          
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-user"></i><span> Admin</span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">

                    <li>
                        @can('User List')
                        <a href="{{route('user.index')}}">User</a>
                        @endcan
                    </li>
         
                    <li>
                        @can('Customer List')
                        <a href="{{route('customer.list')}}">Customers</a>
                        @endcan
                    </li>

                </ul>
            </li>
            @else
            @endif

           

          




            <!-- @if(auth()->user()->can('role list'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-cog"></i><span> Role && Permission</span> <span

                        class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled"> -->
                    <!-- <li>
                        @can('permission group list')
                            <a href="{{route('permission_group.index')}}" class="waves-effect"><i class="fa fa-cubes"></i><span> Permission Group   </span></a>

                        @endcan
                    </li>
                    <li>
                        @can('permission list')
                            <a href="{{route('permission.index')}}" class="waves-effect"><i class="fa fa-cubes"></i><span> Permission </span></a>

                         @endcan
                    </li> -->

                    <!-- <li>
                        @can('Role List')
                            <a href="{{route('role.index')}}" class="waves-effect"><i class="fa fa-cubes"></i><span> Role </span></a>
                        @endcan
                    </li>
                    <li>
                        @can('Assign User Role List')
                            <a href="{{route('Assign_role_user.index')}}" class="waves-effect"><i class="fa fa-cubes"></i><span> Assigned User Role  </span></a>
                        @endcan

                    </li>

                </ul> -->
            <!-- </li>
            @else
            @endif -->
            @if(auth()->user()->can('System Setting') or auth()->user()->can('Permission Group List') or auth()->user()->can('Permission List') or auth()->user()->can('Role List') or auth()->user()->can('Assign User Role List') or auth()->user()->can('About Us List') or auth()->user()->can('Blog List') or auth()->user()->can('Contact List') or auth()->user()->can('Delivery List') or auth()->user()->can('FAQS List') or auth()->user()->can('Privacy List') or auth()->user()->can('Terms List'))
            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-cog"></i><span> Settings</span> <span

                    class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="list-unstyled">
              
                     <li>
                        @can('Permission Group List')
                            <a href="{{route('permission_group.index')}}" class="waves-effect"><span> Permission Group   </span></a>

                        @endcan
                    </li>
                    <li>
                        @can('Permission List')
                            <a href="{{route('permission.index')}}" class="waves-effect"><span> Permission </span></a>

                         @endcan
                    </li>
                <li>
                @can('Role List')
                    <a href="{{route('role.index')}}" class="waves-effect">User Role</a>
                @endcan
            </li>
           
                    
            <li>
                
                @can('Assign User Role List')
                    <a href="{{route('Assign_role_user.index')}}" class="waves-effect">Assigned User Role</a>
                @endcan

            </li>
            <li>
                @can('System Setting')
                    <a href="{{route('user.edit',Auth::user()->roles[0]->id)}}" class="waves-effect">System Settings</a>
                @endcan

            </li>
                <li >
                    <a href="javascript:void(0);"><span>Site Settings</span><span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                    <ul class="sub-menu">
           
          
                    <li>
                        @can('About Us List')
                        <a href="{{route('about.index')}}">About Us</a>
                        @endcan
                    </li>
                    <li>
                        @can('Privacy List')
                        <a href="{{route('privacy.index')}}">Privacy & Policy</a>
                        @endcan
                    </li>
                    <li>
                        @can('Terms List')
                        <a href="{{route('terms.index')}}">Terms</a>
                        @endcan
                    </li>
                    <li>
                        @can('FAQS List')
                        <a href="{{route('faqs.index')}}">Faqs</a>
                        @endcan
                    </li>
                    <li>
                        @can('Contact List')
                        <a href="{{route('contact.index')}}">Contact</a>
                        @endcan
                    </li>
                    <li>
                        @can('Blog List')
                        <a href="{{route('blog.index')}}">Blog</a>
                        @endcan
                    </li>
                    <li>
                        @can('Delivery List')
                        <a href="{{route('delivery.index')}}">Delivery</a>
                        @endcan
                    </li>
                    </ul>
                </li>
                    <!-- <li><a href="email-setting.html">Email Settings</a></li> -->
                    @can('Enquiry List')
                    <li><a href="{{route('contactlist.index')}}">Enquiry List</a></li>
                    @endcan
                 
                </ul>
            </li>
            @else
            @endif
            @if(auth()->user()->can(''))

            @else
            @endif
            @hasrole('admin')
 <li>
                <a href="#" class="waves-effect"><i class="fa fa-paint-brush"></i><span> Clear cache </span></a>
            </li>
            <!--<li>-->
            <!--    <a href="{{url('clearcache')}}" class="waves-effect"><i class="fa fa-paint-brush"></i><span> Clear cache </span></a>-->
            <!--</li>-->
            @else
            @endhasrole

        </ul>
    </div>
    <div class="clearfix"></div>
</div> <!-- end sidebarinner -->
</div>

